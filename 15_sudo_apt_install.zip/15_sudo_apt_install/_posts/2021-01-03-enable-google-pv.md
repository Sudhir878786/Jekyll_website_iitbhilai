---
title: Latex
author:
  name: Sudhir Shrama 
  link: https://github.com/SilleBille
date: 2021-12-05 18:32:00 -0500
categories: [Blogging, Tutorial]
tags: [google analytics, pageviews]
---





﻿Beginner's LaTeX Guide

This guide should be used as a starting point for learning Latex (pronounced \lay-tek"), but is in no way a full manual. There is an enormous amount of documentation on Latex online. In particular, the wikibooks guide is very useful ([http://en.wikibooks.org/wiki/LaTeX/Introduction) and contains ](http://en.wikibooks.org/wiki/LaTeX/Introduction)nearly all the information needed for a beginner. Consult these resources for further examples and lists of useful commands.

1  Installation

Windows

For TeXnicCenter, go to the link: [http://miktex.org/2.8/setup. Download](http://miktex.org/2.8/setup) and install the Basic MiKTeX 2.8 Installer. Download and install the TexnicCenter Installer at [http://www.texniccenter. org/resources/downloads/29. When](http://www.texniccenter.org/resources/downloads/29) you run TexnicCenter a setup window will ask you for the direc- tory of the executable les. These les are typically located in C:/Program Files/Miktex2.8/miktex/bin. There are also many other good latex editors for Windows.

Ubuntu

In the terminal:

$ sudo apt-get install texlive-full

$ sudo apt-get install gedit-latex-plugin

This will install a Latex plugin to the text editor gedit. Alternatively, you can use Emacs.

Mac

TexShop is a popular, lightwieght software. [http://www.uoregon.edu/~koch/texshop/obtaining. html.](http://www.uoregon.edu/~koch/texshop/obtaining.html)

2  Getting started

The latex code consists of two general parts:

The preamble consists of the parameters for the document, i.e. the margins, the font, the spacing,

the document type, supplementary packages, etc. Some Latex commands require the use of a package dened in the preamble.

The body contains the text, gures, tables, etc. A basic latex document would look like

\documentclass[12pt]{article} \usepackage[left=2cm,top=1cm,right=3cm,bottom=1cm]{geometry} \usepackage{amsmath}

\usepackage{graphicx}

\begin{document}

This is some text about Latex. Latex is great for writing physics and math.

Here is a new paragraph. Notice the double space between the paragraphs.

%This line is a comment since it has a percent sign at the %beginning. None of this text will be read by the program.

Here is an equation \begin{equation} \vec{F} = m \vec{a} \end{equation}

The above equation uses the command \vec{} to put an arrow over the force and acceleration.

...tables ...more text ...figures

\end{document}

The \documentclass[12pt]{article} species the type of document. In most cases, the article class is used. Other options include report and book. See a LATEXmanual for explanations of these other options.

The geometry package is a useful package for specifying the margin widths. The left, right, top, and bottom margins can be specied in centimeters (cm) or inches (in). There are other options which can added to this package. For further documentation see [ftp://ftp.tex.ac.uk/tex-archive/ macros/latex/contrib/geometry/geometry.pdf.](ftp://ftp.tex.ac.uk/tex-archive/macros/latex/contrib/geometry/geometry.pdf)

The amsmath package is needed to improve the appearance of mathematical formulas.

The graphicx package is needed for including gures in a document.

The body of the document is sandwiched between \begin{document} and \end{document}. The body contains all the text, gures, tables, etc. of the document.

Notice that all commands in Latex begin with a backslash.

3  Adding text

In the body of the document, the text can written exactly as it should appear in the compiled document. A double space between paragraphs in the code will produce a paragraph with an indent and no space between lines in the compiled document. To manually change the vertical spacing between lines add the command \vspace{x cm}, where x is the amount of spacing in centimeters. Similarly, for horizontal spacing use \hspace{x cm}.

Size

The size of the font can be adjusted as such

{\Large This text will be very large} {\tiny This text will be very small}

The choice in sizes are

1. \tiny
1. \scriptsize
1. \footnotesize
1. \small
1. \normalsize
1. \large
1. \Large
1. \LARGE
9. \huge
9. \Huge

Font

The font can be adjusted one of two ways:

\textrm{...}

{\rmfamily ...}

Both ways will produce text with roman font. Other options for fonts include



|Command|Alternative|Output|
| - | - | - |
|\textsf{...}|{\sffamily ...}|Sans serif font|
|\texttt{...}|{\ttfamily ...}|Teletype font|
|\textit{...}|{\itshape ...}|Italic|
|\textsc{...}|{\scshape ...}|Small capitals|
|\textbf{...}|{\bfseries ...}|Bold font|
Comments

To comment a section of text use the % symbol before the text. For block comments use the package \usepackage{verbatim}, with the command

\begin{comment} ... \end{comment}

Spacing

Dene the lines spacing in the preamble with the package \usepackage{setspace}. Use the command

\begin{doublespace/onehalfspace/singlespace} ...

\end{double space/onehalfspace/singlespace}

The default setting is singlespace. For a space between lines use \\.

Special Characters

Certain characters are used within the Latex code for various commands and therefore can not simply be used in text. These include

\# $ % & ~ \_ ^ \ { }

To use these symbols put a backslash in front. For example \$ will create a $. A backslash can be made with the \backslash command. Quotes can be made by using

`` ... ''

where the rst symbols are two open quote symbols (on the key with the tilde) and the second symbols

are two single quote marks.

4  Figures

To insert a gure (often called a oat) use the command

\begin{figure}[h!]

\centering

\includegraphics[width=4in]{C:/path/figure.pdf}

\caption[This is the caption to the figure. By including this command

latex will automatically keep track of the numbering of the figures and will place the label "Figure 1, 2 ...".}

\

\end{figure}

\centering will place the gure in the center of the page. Use \flushleft or \flushright for gures on the left and right side of the page.

The [h] is the placement specier which selects where Latex should place the gure.

h = here, t = top of page, b = bottom of page, p = special oats page, and ! can be added to override the internal Latex parameters for determining where to place the gure. To place the gure exactly where the gure appears in the code, use Hwith the package \usepackage{float}. The placement of gures is often one of the most dicult parts of a Latex document, and it requires some manipulation

to produce the desired results.

The \includegraphics[options]{path} command can take several options, including the width

of the gure, cropping, and rotations. Be sure that you do not use backslashes in the path name.

The caption is an optional command which will add a caption and numbering below the gure.

There are many more options for manipulating gures, including wrapping gures around text and placing gures next to each other. See the \Floats, Figures and Captions" and \Importing Graphics" sections of the Wikibooks guide for a reference.

5  Tables

A simple 3  4 table can be created with the tabular environment

\begin{center}

\begin{tabular}{ | l | l | l | l |} \hline

Trial & Temp & Frequency [Hz]\\ \hline 1 & 11C & 2 \\ \hline

2 & 15C & 10 \\ \hline

3 & 22C & 21 \\

\hline

\end{tabular}

\end{center}

The tabular environment is dened with \begin{tabular}{specifications of table}. The specications can include



|l|left-justied column|
| - | - |
|c|centered column|
|r|right-justied column|
|p{width}|paragraph column with text vertically aligned at the top|
|m{width}|paragraph column with text vertically aligned in the middle (requires array package)|
|b{width}|paragraph column with text vertically aligned at the bottom (requires array package)|
|||vertical line|
||||double vertical line|
The arguement of the tabular function is therefore a combination of these commands in the order they should be drawn for one row. \hline creates a horizontal line. The text for each row is added in the order ti should appear. Use &to separate columns. Be sure to include a new line, \\ and \hline after each column. There are numerous other modications for tables in Latex. See the \Tables" sections of the Wikibook page for further information.

6  Math

Perhaps the most important function of Latex is its ability to easily print equations. An example equation which will produce Maxwell's equations is

\begin{equation}

\nabla \cdot \vec{E} = \frac{\rho}{\epsilon\_0}\\ \end{equation}

\begin{eqnarray}

\nabla \cdot \vec{B} &=& 0 \nonumber \\

\nabla \times \vec{E} &=& - \frac{\partial B}{\partial t} \nonumber \\ \nabla \times \vec{B} &=& \mu\_{0}\vec{J} + \mu\_{0}\epsilon\_{0}\frac{\partial E}{\partial t}

\end{eqnarray}

The \begin{equation} begin the equation environment in which the equation is written. The equation will automatically be numbered. For non-numbered equations use \begin{equation\*}. All mathematical symbols can be found on Latex symbols tables online ([http://omega.albany.edu: 8008/Symbols.html ](http://omega.albany.edu:8008/Symbols.html)is fairly complete). Greek letters are written as \nameOfGreekLetter. Cap- italize the rst letter of the Greek name for the capital greek letter. To create a multiline equa-

tion use the \begin{eqnarry} environment with \\ between each line. Place &...& around the character where the equations should line up. That is, in this case the three equal signs will be aligned. The \nonumber command will remove the numbering for any of the lines. For fractions use \frac{numerator}{denometer}. For subscripts and superscripts use x\_{2} and x^{2} respectively.

For inline math, put $ .. $ around the equation. Be sure that any time you write a mathematical symbol, you place $ ... $ around it. See references online for further examples and tips.

7  Sections

To create a numbered section use \section{Name of Section}. All text below this command will be indented inside this section, and the section will be properly numbered. For non-numbered sections, use \section\*{Name}. For subsections, use \subsection{Name}.

8  Further topics not covered

These are many topics not covered in this manual. Below are a few which may be useful to read about.

1. Bibtex is a very useful way of citing references.
1. Labels can be added to gures and tables so they can easily be cited in the text. For gures it is implemented with \label{fig:animals}.
1. Colors can be added with the colors package.
PAGE5