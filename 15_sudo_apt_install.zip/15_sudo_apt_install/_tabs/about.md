---
---


We Have use Multple Language like React for making search bar using `usesate  ` also tab bar and basic HTML/CSS for desining the page   (left side tab bar )  
there are some error like sort warning  which i couldn't resolve 




.



*NAME* `Sudhir Sharma` 

Email: *sudhirsharma34567@gmail.com*




`*Objective:* `

Seeking a challenging opportunity in an organization which recognizes and utilizes my true potential while nurturing analytical and technical skills.

`*Summary:*`

Good knowledge in Machine Learning Algorithms. Good knowledge in statistics.

Having good knowledge in pre-processing of data using python. Having logical and analytical mind-set for data preparation.

Good knowledge in data visualization tool- Tableau

Good knowledge in Software Development Life Cycle (SDLC)

`*Education:*`

*IIT BHILAI*


Btech Computer Science 2020-24





BTech in Computer Science & Technology: 7.6 CGPA


Duration


*BHU*

Intermediate : 95.5%							Duration


`*Projects:*`

*Base Price Prediction of a Player in Indian Premier League:*


Language/Platform: Python2.7					Duration

This Framework aims at predicting the base price of all players for upcoming season of IPL based on the recent performance of the players in different international and domestic leagues. The model is trained as such to generate a score from the extracted features, based on the range of which the base price is generated using machine learning libraries.

*Performance Evaluation of Texture Descriptors: A Case Study on Sign Language Recognition*

Language/Platform: Matlab (R2014a)  

Performance evaluation of framework model for detection and conversion of sign language into equivalent natural-language sentences using texture descriptors, implemented in MATLAB.

*Graph Coloring using Breadth First Search (BFS)*

Language/Platform: C++							Duration


Research-based project implementing Vizing’s theorem: graph coloring in which no two adjacent vertices have the same color, implemented with object-oriented programming in C++.

*Certifications:*


||PG-Diploma in Big Data Analytics from CDAC|            
| :- | :- | :- |
||Big Data and Hadoop (Online Course)|Edvancer Eduventures|
||Software Testing (Manual and Automation (Selenium))—|QSpiders|
||Core java -||QSpiders|
|*Technical Skills:*||||
|Languages|: C, core Java, Python, R||
|Databases|: SQL, MongoDB||
|Testing|||: Manual Testing,||
|Tools|||: Rstudio 3.4.1, MATLAB||

Machine Leaning Algorithms: Decision trees, K-means clustering, KNN classification, Random forest, Support Vector Machine (SVM), Gradient Boosting etc. Good knowledge in Statistics


*Achievements:*

- Awarded District-level prize in Computer Science exam in High School
- Participated in Chess competition at inter-university level
- Presentation: Seminar personated on “Open Source Software System and Traditional Software Systems”.
- Participated in quiz competition at inter-class level.