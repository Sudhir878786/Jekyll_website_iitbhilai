---

---
*ABHAY SINGH PATEL*

Uttar Pradesh,India[ abhaysinghpatel690@gmail.com ](mailto:abhaysinghpatel690@gmail.com)[ Abhay Singh Patel/IIT BHILAI ](https://linkedin.com/in/Abhay Singh Patel/IIT BHILAI)[ rutor-86 ](https://github.com/rutor-86)**EDUCATION![](Aspose.Words.ad31b8aa-5c7f-4cd1-a6aa-d526efe23439.001.png)**

*Indian Institute Of Technology Bhilai* Month, Year B-tech in Computer Science, CGPA: 8.21 Aug. 2020 - Jun. 2024

*St.Peter’s School,* ICSE Month, Year ABCDEF, Percentage: 82.1% Apr. 2018 - Apr. 2019

*SKILLS![](Aspose.Words.ad31b8aa-5c7f-4cd1-a6aa-d526efe23439.002.png)*

*Languages & Frameworks* HTML, CSS, Javascript, Typescript, NodeJS,Verilog,Python,Java,C++ *Software & Tools* Linux, Windows, SSH, Git,

*Other* Microsoft Word, Microsoft PowerPoint, Adobe Photoshop

*WORK EXPERIENCE![](Aspose.Words.ad31b8aa-5c7f-4cd1-a6aa-d526efe23439.003.png)*

[*Example.com*](https://example.com) Xyz, XX Software Developer Jun. 2017 - Oct. 2019

- contributed to open source of NASA mission.
- Created REST APIs in backend using Express and MongoDB
- deployed some of the self made game at heroku
- Added automated API

*PROJECTS![](Aspose.Words.ad31b8aa-5c7f-4cd1-a6aa-d526efe23439.004.png)*

[*,* ](https://github.com/Abhay-86/Virtual-IIT-Bhilai)IIT BHILAI Jan. 2020 - Mar. 2020

- Led a team to design and develop the website using *NodeJS* and MySQL
- Created user management feature, including full auth flow
- Deployed site on AWS, using EC2 and RDS

*ACTIVITIES AND ACHIEVEMENTS![](Aspose.Words.ad31b8aa-5c7f-4cd1-a6aa-d526efe23439.005.png)*

Most Innovative Idea, Project Website Competition, 2013 Awarded 1st Prize, Design Competition, 2014

Hosted a workshop on AWS attended by 100+ students, 2015

*EXTRA-CURRICULAR![](Aspose.Words.ad31b8aa-5c7f-4cd1-a6aa-d526efe23439.001.png)*

*Feb. 2021 - Mar. 2021*

- Inter IIT tournament
- Hackerthon.

*COURSERA COURSES![](Aspose.Words.ad31b8aa-5c7f-4cd1-a6aa-d526efe23439.004.png)*

*Core Courses Other Courses* Operating System Algorithm Machine Learning Data Structure Artificial Intelligence ADLD
