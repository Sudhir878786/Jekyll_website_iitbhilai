---

---
`*Sharisth Singh*`

Email - sharisthsingh@iitbhilai.ac.in 

![](Aspose.Words.a224eec8-bc46-4f6a-8ad5-32e1ff8ab884.001.png)


*ADDRESS*

Flat No AF-327, 3rd Floor, Sri Krishna Apartments, Hanapara, Kolkata, West Bengal - 700101


`*SKILLS*`

*Operating System* - Windows,** Linux, Mac OS

*Tools* - MS Word, MS Excel,** Eclipse, Netbeans

*Programming Languages* -** Java, Python



`*SOCIAL PROFILES*`

*Facebook* - http://www.fb.com

*Quora* -

http://www.quoram.com

`*ACADEMIC DETAILS*`

*St.Mary Delhi*

X | 2018

Marks - 85.50%,

*St. Mary's*

XII | 2020

Marks - 76.00%,

`*IITBHILAI*`

* Computer Engineering & Management*

`*Studies*`

B.Tech/B.E. | 2024 Marks - 



`*SUMMARY*`

Ambitious to kick start the career with globally recognized organization which will give me global exposure to enhance my skills and knowledge for mutual benefits of the organization.

`*CERTIFICATES*`

*V.T. ON ADVANCE PLC PROGRAMMING & SCADA*

This certificate was issued after completion of a three month online course on

Advanced PLC programming. The coursework also included

engineering a

SCADA module.

*CERTIFIED SOFTWARE DEVELOPMENT TRAINEE*

Score - 77/89, Certification Link - https://www.myamcat.com/certificate/4460755/software-development-trainee/166

Certificate in Advanced JAVA issued by HP.

Course duration - 2 months

Learned concepts of advanced java

*PENETRATION TESTING FROM XDRG*

Score - 78/100, Certification Link - http://www.pentestcertif.com

`*ACHIEVEMENTS*`

Bagged Best Position as Essay Writing in Std X.

Bagged Best Position as Speech Competition in Std XI.

Awarded 2nd Position in the Hindi Skit Competition on Regional

Level Youth

Fest in 2012.

*PAPERS*



*AN INSIGHT INTO THE HISTORY OF MEDIEVAL EUROPE*

29 Sep'17, Suresh Kumar, Abhimanyu Kumar

In this paper, we discuss various insights into the history of medieval Europe. The focus is on various armors used by knights during this time period. http://www.thirdpaper.com

*PROFESSIONAL DETAILS*

*COGNIZANT TECHNOLOGY SOLUTIONS INDIA PVT LTD*

Engineer Trainee IT IS, 1 Sep'17 to 1 Aug'18

Cognizant IT Application Support

*PROJECTS*

![](Aspose.Words.a224eec8-bc46-4f6a-8ad5-32e1ff8ab884.002.png)

*TEMPERATURE CONTROL OF INDUSTRIAL FURNACE WITH ALARM GENERATION AND TRIPPING USING PLC AND SCADA*

Involved in high level design and complex application features of temperature control of industrial furnace using PLC & SCADA wherein PLC is used to control the operation and SCADA is used to monitor the parameters.